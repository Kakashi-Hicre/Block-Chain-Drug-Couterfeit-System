#!/usr/bin/env sh
# One-time setup on macOS / Linux: creates a virtual environment and installs what the app needs.
set -e
PY="${PYTHON:-python3}"
"$PY" --version
"$PY" -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python run.py --check || true
echo
echo "Setup finished. Start the app with:  .venv/bin/python run.py"
