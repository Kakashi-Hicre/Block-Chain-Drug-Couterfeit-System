@echo off
REM One-time setup on Windows: creates a virtual environment and installs what the app needs.
python --version || (echo Python is not installed or not on PATH. Install it from https://www.python.org/downloads/ and tick "Add python.exe to PATH". & exit /b 1)
python -m venv .venv || exit /b 1
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt || exit /b 1
python run.py --check
echo.
echo Setup finished. Start the app with:  .venv\Scripts\python run.py
