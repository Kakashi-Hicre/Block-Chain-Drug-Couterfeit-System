# Blockchain-Based Counterfeit Drug Detection and Traceability (prototype)

A final-year project: a Python prototype that records the custody history of medicine packages
(Manufacturer → Distributor → Wholesaler → Pharmacy) in a SQLite database **and** in a SHA-256
hash-linked ledger, rejects invalid operations, and verifies any serial number.

* **All data is synthetic.** No real medicine, patient or company data is used.
* "Record verified" means the registered data and custody history are consistent and unaltered.
  It does **not** prove that a medicine is physically authentic. A flagged record needs investigation;
  it is not proof of counterfeiting.
* It is a single-node hash chain (a blockchain *prototype*), not a distributed blockchain network.

![Dashboard](screenshots/ui_home.png)

## 1. What you need

| Requirement | Notes |
|---|---|
| Python **3.9 or newer** | Tested on 3.12 and 3.13. Use the installer from <https://www.python.org/downloads/>. |
| SQLite | **Part of Python itself** (the `sqlite3` module); there is nothing separate to install. See *Troubleshooting* if it is reported missing. |
| tkinter | Included with the Windows/macOS installers. On Linux: `sudo apt install python3-tk`. |
| customtkinter | Installed by `requirements.txt` (the only package the app needs). |
| matplotlib | Optional: only to re-run the experiments and redraw charts (`requirements-experiments.txt`). |

## 2. Quick start

```bash
git clone <your-repository-url>
cd <repository-folder>
```

**Windows**

```bat
setup.bat
.venv\Scripts\python run.py
```

**macOS / Linux**

```bash
./setup.sh
.venv/bin/python run.py
```

Or by hand, on any system:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate        macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
python run.py
```

`run.py` checks the environment (and explains anything missing), builds the synthetic dataset on the first
run, and opens the application. To only check your setup: `python check_environment.py`.

## 3. Using the application

* **Load synthetic dataset** (sidebar): replays 1,000 synthetic packages through the rules and the ledger.
  A progress screen shows the percentage, elapsed time and time left.
* **Use your own medicine** (no dataset needed):
  1. *Register medicine*: type a new batch number, fill in the details, press **Save as new batch**.
  2. Enter a serial number and press **Register medicine**. Keep the details identical to the batch,
     otherwise verification reports a data mismatch.
  3. *Transfer*: one step at a time, always from the current holder, with evidence
     (**Generate evidence** fills it in): Manufacturer_A → Distributor_A → Wholesaler_A → Pharmacy_A.
  4. *Verify*: enter the serial number; a correctly registered and transferred package gives `RECORD_VERIFIED`.
* Participants are fixed: `Manufacturer_A/B`, `Distributor_A/B`, `Wholesaler_A/B`, `Pharmacy_A/B/C`, and the
  deliberately unauthorized `Rogue_Actor`.
* **Blockchain** page: verify the hash chain, save an anchor, or simulate tampering on a copy of the chain.

## 4. Tests and experiments

```bash
python test_phase2.py        # ... through test_phase6.py (writes logs/)
python -m pip install -r requirements-experiments.txt
python experiments.py        # about 3 minutes; --quick for a short trial
python make_figures.py       # redraw charts from saved logs
```

`test_phase5.py` needs a display (it opens the window). Timings depend on the computer; see
`logs/phase6_environment.txt` for the machine the reported numbers came from.

## 5. Troubleshooting

Run `python check_environment.py` first: it names the problem and the fix.

| Message | Cause and fix |
|---|---|
| `No module named '_sqlite3'` / `sqlite3` missing | This Python was built without SQLite (typical for pyenv/source builds on Linux or macOS). Install the SQLite development library (`sudo apt install libsqlite3-dev`, or `brew install sqlite3`), then reinstall Python. Easiest: use the python.org installer, the distribution's `python3`, or Miniconda. |
| `No module named 'tkinter'` | Windows: re-run the installer → Modify → tick *tcl/tk and IDLE*. Ubuntu/Debian: `sudo apt install python3-tk`. macOS: `brew install python-tk`. |
| `No module named 'customtkinter'` | `python -m pip install -r requirements.txt` (use the same Python you run the app with). |
| `python` not found (Windows) | Reinstall Python and tick *Add python.exe to PATH*, or use `py -m ...` instead of `python -m ...`. |
| Very new Python version (for example 3.15) | The app itself uses only the standard library plus customtkinter. If `pip` cannot install a package for a brand-new Python, use Python 3.12 or 3.13 in a virtual environment. matplotlib is only needed for the experiments. |
| Window text looks too small or large | Adjust the operating-system display scaling; the app follows it. |

## 6. Files

| File | Purpose |
|---|---|
| `run.py`, `check_environment.py`, `setup.bat`, `setup.sh` | Start-up, environment check and setup |
| `gui.py`, `controller.py` | Application window and logic |
| `supply_chain.py`, `ledger.py`, `verifier.py`, `database.py` | Rules, hash-linked ledger, verification engine, SQLite schema |
| `generate_dataset.py` | Synthetic dataset (seed 42) |
| `baseline.py`, `experiments.py`, `figures.py`, `make_figures.py` | Baseline system, experiments, charts |
| `test_phase2.py` … `test_phase6.py` | Automated tests |
| `dataset/`, `logs/`, `figures/`, `screenshots/` | Data, saved results, charts, screenshots |
