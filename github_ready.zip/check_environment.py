"""
check_environment.py - tells you whether this computer can run the project, and how to fix what is missing.

Run:  python check_environment.py
Exit code 0 = ready, 1 = something required is missing.
"""
import importlib
import os
import platform
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
MIN_PYTHON = (3, 9)
PIP = f'"{sys.executable}" -m pip install -r requirements.txt'
SYSTEM = platform.system()

SQLITE_HELP = {
    "Windows": ["Reinstall Python from https://www.python.org/downloads/ (the official installer includes SQLite).",
                "Do not use a stripped-down or embeddable Python build."],
    "Darwin": ["Install Python from https://www.python.org/downloads/ or with Homebrew: brew install python",
               "If you use pyenv: brew install sqlite3 xz, then reinstall the Python version with pyenv."],
    "Linux": ["Debian/Ubuntu:  sudo apt install libsqlite3-dev   (then reinstall/rebuild Python if you built it yourself)",
              "Fedora:         sudo dnf install sqlite-devel",
              "pyenv/source builds: install libsqlite3-dev first, then run  pyenv install <version>  again.",
              "Or use the distribution's own python3 package, or Miniconda/Anaconda, which include SQLite."],
}
TK_HELP = {
    "Windows": ["Re-run the Python installer, choose Modify, and tick 'tcl/tk and IDLE'."],
    "Darwin": ["Use the python.org installer, or: brew install python-tk"],
    "Linux": ["Debian/Ubuntu:  sudo apt install python3-tk", "Fedora:         sudo dnf install python3-tkinter"],
}


def _try(name):
    try:
        return importlib.import_module(name), None
    except Exception as e:                      # ImportError, or a broken build
        return None, e


def check(verbose=True):
    """Returns (ok, problems). Prints a short report when verbose."""
    problems, lines = [], []

    def say(ok, text):
        lines.append(("  [ OK ] " if ok else "  [FAIL] ") + text)

    v = sys.version_info
    ok = (v.major, v.minor) >= MIN_PYTHON
    say(ok, f"Python {v.major}.{v.minor}.{v.micro} ({'needs ' + '.'.join(map(str, MIN_PYTHON)) + ' or newer' if not ok else platform.python_implementation()})")
    if not ok:
        problems.append(("Python is too old", [f"Install Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]} or newer from https://www.python.org/downloads/"]))

    mod, err = _try("sqlite3")
    if mod:
        say(True, f"sqlite3 module (SQLite {mod.sqlite_version})")
    else:
        say(False, f"sqlite3 module is missing ({err})")
        problems.append(("SQLite support is missing. SQLite is part of Python itself, so this Python was built without it. Fix:",
                         SQLITE_HELP.get(SYSTEM, SQLITE_HELP["Linux"])))

    mod, err = _try("tkinter")
    if mod:
        say(True, f"tkinter (Tk {mod.TkVersion})")
    else:
        say(False, f"tkinter is missing ({err})")
        problems.append(("tkinter (the window toolkit) is missing. Fix:", TK_HELP.get(SYSTEM, TK_HELP["Linux"])))

    tk_ok = "tkinter" in sys.modules and sys.modules["tkinter"] is not None
    mod, err = _try("customtkinter") if tk_ok else (None, None)
    if not tk_ok:
        lines.append("  [ -- ] customtkinter not checked yet (it needs tkinter first)")
    elif mod:
        say(True, f"customtkinter {getattr(mod, '__version__', '')}")
    else:
        say(False, f"customtkinter is not installed ({err})")
        problems.append(("customtkinter is not installed. Fix:", [PIP]))

    mod, err = _try("matplotlib")
    lines.append(("  [ OK ] " if mod else "  [ -- ] ") +
                 (f"matplotlib {mod.__version__} (only needed for experiments.py / make_figures.py)" if mod else
                  "matplotlib not installed (optional: only for experiments.py / make_figures.py; "
                  f'install with "{sys.executable}" -m pip install -r requirements-experiments.txt)'))

    if verbose:
        print("Environment check")
        print("\n".join(lines))
        for title, fixes in problems:
            print("\n" + title)
            for f in fixes:
                print("    " + f)
        print("\nReady to run: python run.py" if not problems else "\nFix the items above, then run this check again.")
    return not problems, problems


if __name__ == "__main__":
    sys.exit(0 if check()[0] else 1)
