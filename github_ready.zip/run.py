"""
run.py - start the application on any computer.

  python run.py            check the environment, build the synthetic dataset if needed, open the app
  python run.py --check    only check the environment

All data is synthetic.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)                                   # the app looks for dataset/ and logs/ next to the code
sys.path.insert(0, HERE)


def main():
    from check_environment import check
    ok, _ = check()
    if "--check" in sys.argv or not ok:
        return 0 if ok else 1
    if not (os.path.exists("dataset/batches.csv") and os.path.exists("pharma_traceability.db")):
        print("\nFirst run: building the synthetic dataset (a few seconds)...")
        import generate_dataset
        generate_dataset.main()
    from gui import App
    App().mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
